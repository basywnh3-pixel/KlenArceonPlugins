package com.klenmc.klenarceon;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.Locale;

public final class KlenArceon extends JavaPlugin implements Listener {
    private static final String PREFIX = ChatColor.DARK_PURPLE + "[KlenArceon] " + ChatColor.LIGHT_PURPLE;

    @Override public void onEnable() {
        Bukkit.getPluginManager().registerEvents(this, this);
        getLogger().info("KlenArceon enabled. Initial tools: //arch and //road.");
    }

    @Override public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0 || args[0].equalsIgnoreCase("help")) {
            sender.sendMessage(PREFIX + "Version 0.1.0 — Paper 1.21.4");
            sender.sendMessage(ChatColor.WHITE + "//arch <material> <width> <height>");
            sender.sendMessage(ChatColor.WHITE + "//road <material> <length> <width>");
            sender.sendMessage(ChatColor.GRAY + "These are the first implemented tools; more tools will be added in later builds.");
            return true;
        }
        sender.sendMessage(PREFIX + "Use //arch or //road in-game, or /klenarceon help.");
        return true;
    }

    @EventHandler public void onDoubleSlash(PlayerCommandPreprocessEvent event) {
        String raw = event.getMessage();
        if (!raw.startsWith("//")) return;
        String[] a = raw.substring(2).trim().split("\\s+");
        if (a.length == 0) return;
        String tool = a[0].toLowerCase(Locale.ROOT);
        if (!tool.equals("arch") && !tool.equals("road")) return;
        event.setCancelled(true);
        Player p = event.getPlayer();
        if (!p.hasPermission("klenarceon.use")) { p.sendMessage(PREFIX + ChatColor.RED + "You don't have permission."); return; }
        try {
            if (tool.equals("arch")) buildArch(p, a);
            else buildRoad(p, a);
        } catch (IllegalArgumentException ex) {
            p.sendMessage(PREFIX + ChatColor.RED + ex.getMessage());
        }
    }

    private void buildArch(Player p, String[] a) {
        if (a.length != 4) throw new IllegalArgumentException("Usage: //arch <material> <width> <height>");
        Material m = material(a[1]); int width = positive(a[2], 3, 61); int height = positive(a[3], 3, 40);
        if (width < 3 || height < 3) throw new IllegalArgumentException("Width and height must be at least 3.");
        Location base = p.getLocation().getBlock().getLocation().add(p.getLocation().getDirection().setY(0).normalize().multiply(4));
        World w = p.getWorld(); int cx = base.getBlockX(), y = base.getBlockY(), cz = base.getBlockZ();
        double rx = width / 2.0, rz = Math.max(1.0, width / 5.0);
        int changed = 0;
        for (int x = 0; x < width; x++) {
            double nx = (x - rx) / rx;
            int top = (int)Math.round(height * Math.sqrt(Math.max(0, 1 - nx * nx)));
            for (int yy = 0; yy <= top; yy++) {
                // Leave the opening clear; build only the arch ring.
                int innerTop = Math.max(0, top - Math.max(1, width / 10));
                if (yy >= innerTop || x == 0 || x == width - 1 || yy == 0) {
                    Block b = w.getBlockAt(cx + x - width / 2, y + yy, cz);
                    b.setType(m, false); changed++;
                }
            }
        }
        p.sendMessage(PREFIX + "Built a simple arch. Blocks changed: " + changed);
    }

    private void buildRoad(Player p, String[] a) {
        if (a.length != 4) throw new IllegalArgumentException("Usage: //road <material> <length> <width>");
        Material m = material(a[1]); int length = positive(a[2], 1, 200); int width = positive(a[3], 1, 41);
        Location start = p.getLocation().getBlock().getLocation().add(p.getLocation().getDirection().setY(0).normalize().multiply(3));
        int dx = Math.abs(p.getLocation().getDirection().getX()) > Math.abs(p.getLocation().getDirection().getZ()) ? 1 : 0;
        int dz = 1 - dx; int changed = 0;
        for (int i = 0; i < length; i++) for (int j = 0; j < width; j++) {
            int ox = dx == 1 ? i : j - width / 2; int oz = dz == 1 ? i : j - width / 2;
            start.getWorld().getBlockAt(start.getBlockX() + ox, start.getBlockY() - 1, start.getBlockZ() + oz).setType(m, false); changed++;
        }
        p.sendMessage(PREFIX + "Built a straight road. Blocks changed: " + changed);
    }

    private Material material(String name) {
        Material m = Material.matchMaterial(name);
        if (m == null || !m.isBlock()) throw new IllegalArgumentException("Unknown block material: " + name);
        return m;
    }
    private int positive(String s, int min, int max) {
        try { int n = Integer.parseInt(s); if (n < min || n > max) throw new NumberFormatException(); return n; }
        catch (NumberFormatException ex) { throw new IllegalArgumentException("Number must be between " + min + " and " + max + "."); }
    }
}
