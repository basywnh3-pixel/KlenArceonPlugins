# KlenArceon 0.1.0

An independent starter plugin for Paper 1.21.4. It is not the original Arceon plugin and does not copy its code.

## Implemented in this first build
- `//arch <material> <width> <height>` — creates a simple block arch in front of the player.
- `//road <material> <length> <width>` — creates a straight road in front of the player.
- `/klenarceon help` — help.

Requires Java 21 and Paper 1.21.4. FAWE may remain installed, but this starter build does not yet call the FAWE API.

## Build
Run `mvn package` in this folder. The jar will be created at `target/KlenArceon-0.1.0.jar`.

## Install
Copy the jar into `plugins/`, restart the test server, and grant `klenarceon.use` only to trusted builders. Test in a disposable world first. The tools modify blocks directly and currently do not create FAWE undo history.
